# KNN Recommendation API
This is a Flask-based API for job recommendation using KNN and ESCO database.